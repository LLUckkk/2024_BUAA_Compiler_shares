package frontend.AST;

import frontend.symbol.SymbolStack;

import java.util.ArrayList;

public class CompUnit extends Node {
    public CompUnit(ArrayList<Node> children, SyntaxType type) {
        super(children, type);
    }

    @Override
    public void checkError() {
        //setGlobal 暂时不知道什么意思，先不管
        SymbolStack.getInstance().enterBlock();
        super.checkError();
        SymbolStack.getInstance().exitBlock();
    }
}
