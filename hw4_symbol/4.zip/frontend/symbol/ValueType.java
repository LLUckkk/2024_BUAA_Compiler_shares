package frontend.symbol;

public enum ValueType {
    VOID,
    INT,
    CHAR,
    INT_ARRAY,
    CHAR_ARRAY,
}
