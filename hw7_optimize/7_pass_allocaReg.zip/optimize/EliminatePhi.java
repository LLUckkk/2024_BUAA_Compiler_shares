package optimize;


import llvm_ir.Module;

public class EliminatePhi {
    public Module module;

    public EliminatePhi(Module module) {
        this.module = module;
    }

    public void optimize() {

    }
}
