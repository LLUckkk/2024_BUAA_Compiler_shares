package optimize;

public class Mem2Reg {

    public void optimize() {

    }

}
