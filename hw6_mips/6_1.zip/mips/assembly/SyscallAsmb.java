package mips.assembly;

import mips.Assembly;

public class SyscallAsmb extends Assembly {
    public String toString() {
        return "syscall";
    }
}
