package mips.assembly;

import mips.Assembly;

public class GlobalAsmb extends Assembly {
    protected String name;

    public GlobalAsmb(String name) {
        this.name = name;
    }
}
