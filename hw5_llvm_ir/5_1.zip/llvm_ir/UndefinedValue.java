package llvm_ir;

public class UndefinedValue {
}
